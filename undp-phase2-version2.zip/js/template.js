
/**
 * Inside the system parameter, it is needed to fix the state of the preloader. 
 * It is further passed to the Promise when the events are called.
 * @type {LoadResult<Object>}
 */
var loadResult = {
    status: false,
};

/**
 * A group of methods for rendering templates.
 * To render templates, a pre-prepared wrapper and parameters that were previously generated are passed, they are needed to form the state of the preloader, whether it is a progress bar or a fade animation.
 * Each method returns its render from the "template" parameter match
 * @type {{linear: (function(HTMLElement, Object): HTMLElement), gearSet: (function(HTMLElement, Object): HTMLElement), custom: (function(HTMLElement, Object): HTMLElement), resizeBox: (function(HTMLElement, Object): HTMLElement), cubs: (function(HTMLElement, Object): HTMLElement), pulsar: (function(HTMLElement, Object): HTMLElement), flash: (function(HTMLElement, Object, HTMLElement=): HTMLElement)}}
 */
const templatesPreload = {

    /**
     * Method for rendering template Linear
     *
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement}
     */
    linear: function(element,options) {
    
        const wrapperLinearLine = document.createElement('div');
        const counter  = document.createElement('div'); 
        const progress = document.createElement('div'); 

        wrapperLinearLine.setAttribute('id',options.template);
        
        counter.setAttribute('id','count');
        progress.setAttribute('id','progress');

        progress.appendChild(wrapperLinearLine);
        progress.appendChild(counter);

        if(options.style) {
            wrapperLinearLine.style.backgroundColor = options.style.progress_color;
        }

        element.appendChild(progress);

        let animateElement = animateOut['open'](element,options);

        load.progress(function(result) {
            
            let progressLoad = result.progress;

            wrapperLinearLine.style.width = progressLoad + '%';

            if(options.progressBar) {
                if(options.progressBar.color) {
                    counter.style.color = options.progressBar.color;
                }
                counter.innerHTML = Math.round(progressLoad) + '%';
            }

            if(load.done()) {
                if(options.defaultOut) {
                    load.hidden(options);
                } else {
                    if(options.animationOut) {
                        animateOut[options.animationOut]()
                    } else {
                        setTimeout(function() {
                            if(animateElement) {
                                animateElement.wallTop.style.top     = '-50%';
                                animateElement.wallDown.style.bottom = '-50%';
                                progress.style.display               = 'none';
                            }
                        },100);
                    }
                }
            } 
        },options);

        return element;
    },

    /**
     * Method for rendering template Pulsar
     *
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement}
     */
    pulsar: function(element,options) {
        
        const pulsarElementWrapper = document.createElement('div');
        pulsarElementWrapper.setAttribute('id',options.template);

        for(let i = 0; i < 2; i++) {

            let circle  = document.createElement('div');
            let settings = options.color;

            if (typeof settings === 'string' || settings instanceof String) {
                circle.style.borderColor = settings;
            } else {
                if(settings) {
                    if(i == 1) {
                        circle.style.borderColor = settings.first_circle;
                    } else {
                        circle.style.borderColor = settings.second_circle;
                    }
                }
            }

            pulsarElementWrapper.appendChild(circle);
        }

        element.appendChild(pulsarElementWrapper);

        load.processOut(element,options);

        return element;
    },

    /**
     * Method for rendering template Cubs
     *
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement}
     */
    cubs: function(element,options) {
        
        const cubsElementWrapper = document.createElement('div');
        cubsElementWrapper.setAttribute('id',options.template);

        let params = options.borderColor;
        if (typeof params === 'string' || params instanceof String) {
            cubsElementWrapper.style.color = params;
            cubsElementWrapper.style.boxShadow = "inset 0 0 0 2px "+params;
        } else {
            if(params) {
                if(params.boxLine) {
                    cubsElementWrapper.style.color = params.boxLine;
                }
                if(params.outLine) {
                    cubsElementWrapper.style.boxShadow = "inset 0 0 0 2px "+params.outLine;
                }
            } else {
                let initColor = '#1bd8ec';

                cubsElementWrapper.style.color = initColor;
                cubsElementWrapper.style.boxShadow = "inset 0 0 0 2px "+initColor;
            }
        }
    
        if(options.image) {
            const image = document.createElement('img'); 
            image.setAttribute('src',options.image);

            cubsElementWrapper.appendChild(image);
        }

        element.appendChild(cubsElementWrapper);

        load.processOut(element,options);

        return element;
    },

    /**
     * Method for rendering template ResizeBox
     * 
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement} 
     */
    resizeBox: function(element,options) {

        let colors = {
            one:'#EE4D68',
            two:'#875678',
            three:'#FF9900',
            four:'#00E4F6'
        }
        let duration = options.speed ?? 2000;

        if(options.colors) {
            colors = {...colors,...options.colors};
        }
        
        const resizeBoxElementWrapper = document.createElement('div');
        resizeBoxElementWrapper.setAttribute('id',options.template);

        for(let i = 0; i < 4; i++) {
            const box = document.createElement('span');
            if(i === 0) {
                animateBox(box,'-50px','0',colors.one,duration);
            } else if(i === 1) {
                animateBox(box,'50px','0',colors.two,duration);
            } else if(i === 2) {
                animateBox(box,'0','-50px',colors.three,duration);
            } else if(i === 3) {
                animateBox(box,'0','50px',colors.four,duration);
            }
            resizeBoxElementWrapper.appendChild(box);
        }

        function animateBox(element,translateX,translateY,borderColor,duration) {
            element.animate([
                { transform: 'translate(0)' },
                { transform: 'translate('+translateX+', '+translateY+')',borderColor:borderColor },
                { transform: 'translate(0)' },
              ], {
                duration:duration,
                iterations: Infinity
            })
        }

        let second = ((duration % 60000) / 1000).toFixed(0);
        resizeBoxElementWrapper.style = "animation: resizeBox "+second+"s infinite ease-in-out;"
        element.appendChild(resizeBoxElementWrapper);

        load.processOut(element,options);
        
        return element;
    },

    /**
     * Method for rendering template GearSet
     * 
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement} 
     */
    gearSet: function(element,options) {

        const gearSetElementWrapper = document.createElement('div');
        gearSetElementWrapper.setAttribute('id',options.template);

        for(let i = 1; i < 4; i++) {
            const gear = document.createElement('div');
            gear.setAttribute('id','gear-'+i);
            gear.classList.add('base-gear');
            for(let i = 0; i < 5; i++) {
                const item = document.createElement('div');
                if(i === 0) {
                    item.setAttribute('class','center');
                } else {
                    item.setAttribute('class','tooth');
                }
                gear.appendChild(item);
            }
            gearSetElementWrapper.appendChild(gear);
        }

        element.appendChild(gearSetElementWrapper);

        load.processOut(element,options);
        
        return element;
    },

    /**
     * Method for rendering template Flash
     * 
     * @param {HTMLElement} element
     * @param {object} options
     * @param {HTMLElement} parent
     * @returns {HTMLElement}
     */
    flash: function(element,options,parent = null) {

        let colors = {
            one:'#a28089',
            two:'#a0d2eb',
            three:'#ffa8b6',
            four:'#d0bdf4',
            four:'#494d5f'
        }

        if(options.colors) {
            colors = {...colors,...options.colors};
        }

        parent.style.WebkitTransition = "all 1s;";

        const flashElementWrapper = document.createElement('div');
        flashElementWrapper.setAttribute('id',options.template);

        const loadElement = document.createElement('div');
        loadElement.classList.add('loading');

        flashElementWrapper.appendChild(loadElement);

        element.appendChild(flashElementWrapper);

        load.showProgressBar(element,options);
        load.progress(function(result) {
            load.setProgress(result);
            let progress = parseInt(result.progress);
            let loading  = element.querySelector('.loading');

            if(progress <= 100) {
                if(progress === 0) {
                    parent.style.backgroundColor  = colors.one;
                    loading.style.backgroundColor = colors.one;
                    loading.style.width = 0;
                } else if(progress === 25) {
                    parent.style.backgroundColor  = colors.two;
                    loading.style.backgroundColor = colors.two;
                    loading.style.width = "25%";
                } else if(progress === 50) {
                    parent.style.backgroundColor  = colors.three;
                    loading.style.backgroundColor = colors.three
                    loading.style.width = "50%";
                } else if(progress === 75) {
                    parent.style.backgroundColor  = colors.four;
                    loading.style.backgroundColor = colors.four;
                    loading.style.width = "75%";
                } else if(progress === 100) {
                    parent.style.backgroundColor  = colors.fifth;
                    loading.style.backgroundColor = colors.fifth;
                    loading.style.width = "100%";
    
                    if(load.done()) {
                        if(options.defaultOut) {
                            load.hidden(options)
                        } else {
                            animateOut[options.animationOut]()
                        }
                    } 
                }
            }

        },options);
  
        return element;
    },

    /**
     * Method for rendering template Custom
     * 
     * @param {HTMLElement} element
     * @param {object} options
     * @returns {HTMLElement}
     */
    custom: function(element,options) {

        const customElementWrapper = document.createElement('div');
        customElementWrapper.setAttribute('id',options.template);

        const img = document.createElement('img');
        img.setAttribute('src',options.imagePath);
        img.style.width = '100%';

        customElementWrapper.appendChild(img);

        element.appendChild(customElementWrapper);

        load.processOut(element,options);

        return element;
    }
}

/**
 * Group for handling preloader events
 * @type {{loaded: (function()), showProgressBar: load.showProgressBar, hidden: load.hidden, processOut(HTMLElement, Object): void, setProgress(Object): void, progress: load.progress, done: (function()), events: {trigger: (function(Object, string): Promise<T>), register: load.events.register}}}
 */
const load = {

    /**
     * Progress - an event that tracks the percentage of page load
     * Accepts an anonymous function and code parameters to shape the loading behavior.
     * In this method, the previously mentioned loadResult is formed
     * Here is the logic that generates numbers to form the load string.
     * 
     * @param {function} callback 
     * @param {object} options 
     * 
     * @returns {function}
     */
    progress: function(callback = function() {},options = {}) {
        
        let itemsDOM      = document.getElementsByTagName('*'),
            itemsCountDOM = itemsDOM.length,
            percent       = options.timeOut 
                            ? 2 / ((options.timeOut % 60000) / 1000)
                            : 100 / itemsCountDOM,
            progressLoad  = 0,
            loadedDom     = 0;
            
        let events = this.events;
        (function load() { 
            let requestFrame = requestAnimationFrame(load);
            if(options.timeOut) {
                progressLoad = progressLoad + percent;
                if(progressLoad <= 99) {
                    if(loadedDom > 0) {
                        loadResult.progress = progressLoad;
                    } else {
                        loadResult.progress = 0;
                    }
                    loadedDom++;
                } else {
                    loadResult.status   = true;
                    loadResult.progress = 100;
                    cancelAnimationFrame(requestFrame);
                }
            } else {
                let item = itemsDOM[loadedDom];
                if(item) {
                    progressLoad = progressLoad + percent;
                    if(progressLoad <= 99) {
                        if(loadedDom > 0) {
                            loadResult.progress = progressLoad;
                        } else {
                            loadResult.progress = 0;
                        }
                        loadResult.loadElementDom = loadedDom;
                        loadedDom++;
                    } else {
                        loadResult.status   = true;
                        loadResult.progress = 100;
                        cancelAnimationFrame(requestFrame);
                    }
                }
            }

            events.register('percent_'+loadResult.progress.toFixed());

            if(loadResult.progress <= 0 || loadResult.progress <= 5) {
                events.register('start');
            }
            if(loadResult.progress >= 50 && loadResult.progress <= 51) {
                events.register('loaded');
            }
            if(loadResult.progress === 100) {
                events.register('end');
            }
            
            return callback(loadResult,options);
        })();
    },

    /**
     * Done - The event is fired when the download code has completely loaded.
     * Uses the previously generated global parameter loadResult
     * 
     * @returns {boolean}
     */
    done: function() {
        return loadResult.progress >= 100 && loadResult.status === true;
    },

    /**
     * Loaded - called when the code is doing its work.
     * Uses the previously generated global parameter loadResult
     * 
     * @returns {boolean}
     */
    loaded: function() {
        return loadResult.progress <= 100 && loadResult.status === false;
    },

    /**
     * Preloader hiding method
     * 
     * @param {object} options
     */
    hidden: function(options) {
        let element = document.getElementsByClassName('box_'+options.template)[0];
        if(element) {
            element.classList.add('fadeOut');
            setTimeout(function() {
                element.style.display = 'none';
            },860);
        }
    },

    /**
     * Percent load display method, accepts a wrapper and parameters.
     * If the progressBar property was set in the parameters, then html will be generated and added to the wrapper
     *
     * @param {HTMLElement} element
     * @param {object} options
     */
    showProgressBar: function(element,options) {
        
        if(options.progressBar) {

            let fragment = element.querySelector('#'+options.template);
            let progress = document.createElement('div');
            let color    = "#232323";

            if(fragment) {
                if(options.template === 'resizeBox') {
                    fragment.style.marginBottom = '50px';   
                }
                if(options.template === 'cubs') {
                    progress.style.top = '80px';   
                }
            }            

            if(options.progressBar.color) {
                color = options.progressBar.color;
            }

            progress.setAttribute('id','progress');
            progress.innerHTML   = "0%";
            progress.style.color = color;

            element.appendChild(progress);
        }
    },

    /**
     * Method for setting the download percentage.
     * When the method is called, the "#progress" element is selected, which in turn is drawn by the progressBar property. 
     * If it is not present, the percentage will not be displayed. 
     * It takes the result parameter, which is also loadResult, only in this case it is taken from the event.
     * 
     * @param {object} result
     */
    setProgress(result) {
        let elementProgress = document.querySelector('#progress');
        if(elementProgress) {
            elementProgress.textContent = parseInt(result.progress)+"%";   
        }
    },

    /**
     * Method for hiding the preloader, called in some templates
     * 
     * @param {HTMLElement} element 
     * @param {object} options 
     */
    processOut(element,options) {
        load.showProgressBar(element,options);
        load.progress(function(result) {
           load.setProgress(result);
            if(load.done()) {
                if(options.defaultOut) {
                    load.hidden(options);
                } else {
                    if(options.animationOut) {
                        animateOut[options.animationOut]();
                    } else {
                        load.hidden(options)
                    }
                }
            } 
        },options);
    },
    
    /**
     * Group for registering and calling preloader events
     * * @type {Events<Object>}
     */
    events: {

        /**
         * The method is used to call events previously registered in the progress method
         * 
         * @param {object} options 
         * @param {string} event 
         * 
         * @returns {Promise}
         */
        trigger: function(options,event) {
            return new Promise(resolve => {
                document.addEventListener(event, (e)=>{
                    resolve({...e.detail,...options});
                });
            });
        },

        /**
         * Method for registering events, called in the progress method
         * @param {string} event 
         */
        register: function(event) {
            document.dispatchEvent(new CustomEvent(event, {
                detail: loadResult
            }));
        },
    }, 
};

/**
 * Fade Animation Group
 * As arguments, the preloader render and its parameters are passed to the methods.
 * Optionally, here you can add your own methods for animations with your own style.
 * * @type {AnimateOut<Object>}
 */
const animateOut = {

    /**
     * Opening animation, it is used in the linear template
     * 
     * @param {HTMLElement} element 
     * @param {object} options 
     * 
     * @returns {object}
     */
    open: function(element,options) {

        const wallTop  = document.createElement('div'); 
        const wallDown = document.createElement('div'); 

        wallTop.setAttribute('id','wall_top');
        wallDown.setAttribute('id','wall_down');

        if(options.style) {
            wallTop.style.backgroundColor  = options.style.tob_section_bg_color;
            wallDown.style.backgroundColor = options.style.bottom_section_bg_color;
        }

        element.prepend(wallTop);
        element.appendChild(wallDown);

        return {
            wallTop,
            wallDown
        }
    },

    /**
     * Fade animation to the top.
     */
    slideUp: function() {
        const parent = document.querySelector("#preloader").parentElement.parentElement;

        parent.style.opacity = "0";
        parent.style.top     = "-100%";
    },

    /**
     * Fade animation down.
     */
    slideDown: function() {
        const parent = document.querySelector("#preloader").parentElement.parentElement;

        parent.style.opacity = "0";
        parent.style.top     = "100%";
    },

    /**
     * Fade animation to the right.
     */
    slideRight: function() {
        const parent = document.querySelector("#preloader").parentElement.parentElement;

        parent.style.opacity = "0";
        parent.style.left    = "100%";
    },

    /**
     * Fade animation to the left.
     */
    slideLeft: function() {
        const parent = document.querySelector("#preloader").parentElement.parentElement;

        parent.style.opacity = "0";
        parent.style.left    = "-100%";
    },

    /**
     * Fade animation to the left.
     */
    fadeOut: function() {
        const parent = document.querySelector("#preloader").parentElement.parentElement;

        parent.style.opacity = "0";
    }
}