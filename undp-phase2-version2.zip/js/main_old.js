let loader = new IniLoaders({
    template: "linear",
    // timeOut: 4000, // milliseconde. 
    defaultOut: false,
    // removeAfterLoad:true,
    // animationOut:'slideDown', // slideDown, slideUp, slideLeft, slideRight - need activate defaultOut to "false"
    // testMode:true,
    
    params:{
        linear: {
             progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // style:{
                // tob_section_bg_color:'red',
                // bottom_section_bg_color:'green',
                // progress_color:'#232323',
            // }
        },
        pulsar: {
            // progressBar:true,
            // progressBar:{
            //     color:"red",
            // },
            // backgroundColor:"#f2f2f2",
            // color:"green"
            // color:{
                // first_circle:'yellow',
                // second_circle:'green',
            // }
        },
        cubs:{
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#f2f2f2",
            // image:'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg',
            // borderColor:{
                // boxLine:'yellow',
                // outLine:'green'
            // },
            // borderColor:"red",
        },
        resizeBox: {
            // progressBar:true,
            //  progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#232323",
            // speed:2000,
            // colors:{
                // one:'red',
                // two:'green',
                // three:'yellow',
                // four:'purple'
            // }
        },
        gearSet: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#f2f2f2",
        },
        flash: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // colors:{
                // one:'red',
                // two:'green',
                // three:'yellow',
                // four:'purple',
                // fifth:'purple'
            // }
        },
        custom: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // imagePath: 'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg',
            // backgroundColor:"#ffffff",
        }
    },
});

loader.event('start',function(promise) {
    promise.then(result => {
        console.log(result,'start');
    })
});

loader.event('loaded',function(promise) {
    promise.then(result => {
        console.log(result,'loaded');
    })
});
loader.event('end',function(promise) {
    promise.then(result => {
        console.log(result,'end');
    })
});

loader.event('percent_80',function(promise) {
    promise.then(result => {
        console.log(result,'percent');
    })
});