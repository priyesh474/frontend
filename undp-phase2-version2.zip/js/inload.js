(function() {
    this.IniLoaders = function(options = {},isTestRequest = false) {

        /** 
         * Default options for running code
         * @type {DefaultOptions<Object>}
         */
        IniLoaders.prototype.defaultOpitons = {
            template: 'linear',
            defaultOut: true,
            timeOut: 1000,
            removeAfterLoad: false,
            testMode: false,
            animationOut: false,
            params:{},
            defaultBackgroundColors: {
                cubs:'#232323',
                pulsar:'#232323',
                resizeBox:'#232323',
                gearSet:'#f2f2f2',
                custom:'#232323'
            }
        }
    
        /**
         * Merging the parameters that were passed by the user with the parameters that are set by default.
         * @type {Options<Object>}
         */
        options = {...this.defaultOpitons,...options};
    
        /**
         * Returns all parameters that are available at the time of launch
         * @type {Options<Object>}
         */
        this.allOptions = options;
    
        /**
         * Returns the parameters of all templates
         * @type {Object<Params>}
         */
        this.params = options.params;
    
        /**
         * Returns the parameters of the currently initialized template, if they were provided by the user. 
         * Otherwise it will return empty
         * @type {Params<Object>}
         */
        this.paramsTemplate = options.params[options.template];

        /**
         * Event call method
         * 
         * @param {string} event
         * @param {function} callback
         * 
         * @returns {function}
         */
        this.event = function(event,callback = function() {}) {
            return callback(load.events.trigger(options,event));   
        }
    
        /**
         * Initialization and running code
         */
        IniLoaders.prototype.init = function() {
            
            let classLoad = this;
    
            if(isTestRequest) {
                classLoad.handler();
            } else {
                document.addEventListener('DOMContentLoaded', function() {
                    classLoad.handler();
                });
            }

        },
    
        /**
         * Preloader structure generation handler.
         * And processing the preloader after loading it.
         */
        IniLoaders.prototype.handler = function() {
    
            let fragment = this.createBox();
    
            this.backgroundColor(fragment);
            this.transferedBindElement(fragment);
            this.actionAfterLoad(fragment);
    
            if(options.testMode) {
                panel.init();
                panel.showEvents(new IniLoaders);
            } 
        }
    
        /**
         * Initialization and formation of previously passed parameters
         * Returns an object of generated parameters
         * 
         * @returns {object}
         */
        IniLoaders.prototype.initParametersPreload = function() {
            
            options.classTemplate = 'box_'+options.template;
    
            let params = {};
            if(options.params && options.params[options.template]) {
                params = options.params[options.template];
            }
    
            let timeOut = options.timeOut <= 1000 ? this.defaultOpitons.timeOut : options.timeOut;

            options.timeOut     = timeOut;
            params.template     = options.template;
            params.defaultOut   = options.defaultOut;
            params.timeOut      = timeOut;
            params.animationOut = options.animationOut;
    
            return params;
        }
    
        /**
         * We create a wrapper for the preloader, the template generation is immediately attached. 
         * Template generation is called by the name that was specified in the "template" parameter. 
         * The template call comes from templatesPreload[template]
         * 
         * @returns {HTMLElement} 
         */
        IniLoaders.prototype.createBox = function() {
    
            let parameters = this.initParametersPreload();
    
            let fragment = document.createElement('div');
            fragment.setAttribute('class','box_preload '+options.classTemplate);
        
            let wrapper = document.createElement('div');
            wrapper.setAttribute('id','wrapper_preload');
            
            let preload = document.createElement('div');
            preload = templatesPreload[options.template](preload,parameters,fragment);
            preload.setAttribute('id','preloader');
            
            wrapper.appendChild(preload);
            fragment.appendChild(wrapper);
    
            return fragment;
        }
    
        /**
         * Adding a preloader to the DOM
         * 
         * @param {object} fragment
         */
        IniLoaders.prototype.transferedBindElement = function(fragment) {
            if(isTestRequest) {
                document.getElementById("viewport").appendChild(fragment); 
            } else {
                document.body.prepend(fragment);
            }
        }
    
        /**
         * Handler for removing the preloader from the page after it is fully loaded
         * 
         * @param {object} fragment
         */
        IniLoaders.prototype.actionAfterLoad = function(fragment) {
            if(options.removeAfterLoad) {
                load.progress(function(){
                    if(load.done()) {
                        setTimeout(function() {
                            fragment.remove();
                        },2000);
                    }
                },options)
            }
        }
    
        /**
         * Setting the background color for the preloader, the color is taken from the parameters
         * Accepts previously generated preloaders
         * If the color was passed from the settings, it will be accepted, if not, it will be taken from the default settings
         * 
         * @param {*} fragment 
         */
        IniLoaders.prototype.backgroundColor = function(fragment) {
            let initCorol = options.defaultBackgroundColors[options.template]; 
            if(options.params) {
                let params = options.params[options.template];
                if(params) {
                    if(params.backgroundColor && fragment) {
                        initCorol = params.backgroundColor;
                    }  
                }
            }
            fragment.style.backgroundColor = initCorol;
        },
    
        /**
         * Starting and initializing the preloader
         */
        IniLoaders.prototype.init();
    }
}());