
// document ready function
$(document).ready(function(){


	// $(".category-section").each(function(){
	// 	$(this).find(".category-list").click(function(){
	// 		var dataVal = $(this).attr('data-value');
	// 		if(dataVal == "true"){
	// 			$(this).addClass("active");
	// 		}
	// 		if(dataVal == "false"){
	// 			alert("hii")
	// 			$(this).addClass("notactive");
	// 			$(".true").addClass("active");
	// 		}
	// 	})
	// })

	$(window).on('scroll',function(){
		var WindowTop = $(window).scrollTop();
		if ((WindowTop) > 250) {
			$(".viewport-bg").removeClass("active").addClass("current");
			$(".hero-heading.active, .down-arrow").addClass("current")
			$(".social-bottom").addClass("active");
		} else {
			$(".viewport-bg").addClass("active").removeClass("current");
			$(".hero-heading.active, .down-arrow").removeClass("current")
			$(".social-bottom").removeClass("active");
		}
	  });
	


		$(".category-list").click(function(){
			var dataVal = $(this).attr('data-value');
			if(dataVal == "true"){
				$(this).addClass("active");
			}
			if(dataVal == "false"){
				$(this).addClass("notactive");
				$(this).closest(".category-section").find(".true").addClass("active");
			}
			$(this).parent(".category-listbox").siblings().find(".category-list").css("pointer-events", "none")
		})
	
	


	// $(document).on('click', '[data-accordian]', function(){
	// 	$(this).parent().siblings().find('[data-accordian]').removeClass('active');
	// 	$(this).toggleClass('active');
	// 	$(this).parent().siblings().find('[data-accordian]').next().slideUp();
	// 	$(this).next().slideToggle();
	// 	$(this).parent(".acrd-row").siblings().removeClass("current")
	// 	$(this).parent(".acrd-row").toggleClass("current")
	// })

	// setTimeout(function(){
	// 	b = $("body").outerHeight()
	// 	}, 500)
	// 	$(document).on('click', '[data-accordian]', function(){
	// 	  f = $(this).next(".toggle-box").find(".content-box").outerHeight()
	// 	  $(this).parent().siblings().find('[data-accordian]').removeClass('active');
	// 	  $(this).toggleClass('active');
	// 	  $(this).parent().siblings().find('[data-accordian]').next().css("height", 0);
	// 	  //$(this).next().css("height", 0);
	// 	  //$(this).next().css("height", f);
	// 	  $(this).parent(".acrd-row").siblings().removeClass("current")
	// 	  $(this).parent(".acrd-row").toggleClass("current")
	// 	  if($(this).parent(".acrd-row").hasClass("current")){
	// 		$(this).next(".toggle-box").css("height", f);
	// 		$("body").css("height", f + b)
	// 	  } else {
	// 		$(this).next(".toggle-box").css("height", 0);
	// 		$("body").css("height", b)
	// 	  }
		  
	// 	})

	// $('[data-scroll-bottom]').click(function(){
 //   $('html,body').animate({ scrollTop: 9999 }, 1000);
 // 	})

 	$(document).on('click', '[data-tab]', function(){
		$(this).addClass("active");
		$(this).siblings().removeClass("active");
		var dataTab = $(this).attr('data-tab');
		$('#'+dataTab).siblings().removeClass("active");
		$('#'+dataTab).addClass('active');
	})


	var hh = $("#header").outerHeight()
	$("#scroll-container").css("padding-top", hh)








	 $(document).on("click", ".backtop-section", function(){
	    $('html, body').animate({scrollTop:0},1000);
	  });


$("#header .menu-container  li").each(function(i){

$(this).css({"transform": "translateX("+ (i * 30)+"px" +")"})

})

	$(document).on("click", ".menu-btn, .overlay", function(){
		// $(this).parent(".header-container").append("<div class='overlay'></div>");
        $(".menu-bar, .overlay").toggleClass("active")
        $(".menu-btn").toggleClass("active")
    })

    $(document).on("click", ".show-menu", function(){
        $(this).toggleClass("active")
    })



$(".show-menu").click(function(){
  $(this).find(".submenu").toggleClass("active");
})



	// $(document).on("click",".category-list", function(){

	// 	var dataV = $(this).attr("data-value");
	// 	if(dataV == "true"){
	// 		$(this).addClass("active");
	// 	}else if(dataV == "false"){
	// 		$(this).addClass("notactive");
	// 		$(this).parent(".category-listbox").siblings().find(".category-list").hasAttr("data-value","true").addClass("active");
	// 	}
	// 	$(this).parent(".category-listbox").siblings().find(".category-list").css("pointer-events","none");

	// })



// Twinmax JS

var html = document.documentElement;
var body = document.body;

var scroller = {
  target: document.querySelector("#scroll-container"),
  ease: 0.05, // <= scroll speed
  endY: 0,
  y: 0,
  resizeRequest: 1,
  scrollRequest: 0,
};

var requestId = null;

TweenLite.set(scroller.target, {
  rotation: 0.01,
  force3D: true
});

window.addEventListener("load", onLoad);

function onLoad() {    
  updateScroller();  
  window.focus();
  window.addEventListener("resize", onResize);
  document.addEventListener("scroll", onScroll); 
}


function updateScroller() {
  
  var resized = scroller.resizeRequest > 0;
	
  if (resized) {    
	var height = scroller.target.clientHeight;
	body.style.height = height + "px";
	scroller.resizeRequest = 0;
  }

  var scrollY = window.pageYOffset || html.scrollTop || body.scrollTop || 0;

  scroller.endY = scrollY;
  scroller.y += (scrollY - scroller.y) * scroller.ease;

  if (Math.abs(scrollY - scroller.y) < 0.05 || resized) {
	scroller.y = scrollY;
	scroller.scrollRequest = 0;
  }
  
  TweenLite.set(scroller.target, { 
	y: -scroller.y 
  });
  
  requestId = scroller.scrollRequest > 0 ? requestAnimationFrame(updateScroller) : null;
}

function onScroll() {
  scroller.scrollRequest++;
  if (!requestId) {
	requestId = requestAnimationFrame(updateScroller);
  }
}

function onResize() {
  scroller.resizeRequest++;
  if (!requestId) {
	requestId = requestAnimationFrame(updateScroller);
  }
}


var t = $(".banner-heading").outerHeight()
$(".banner-content").css("top", -(t + 100))


if(screen.width < 1023){
	var t = $(".banner-heading").outerHeight()
	$(".banner-content").css("top", -(t))
}

      
});




// setTimeout(function(){
//  bheee = $("body").outerHeight()
// }, 500)
// $(".acrd-row").each(function(){
// 	var m = $(this).find(".toggle-box").outerHeight()
// 		$(this).click(function(){
// 		$("body").css("height", bheee)
// 		setTimeout(function(){
// 			var b = $("body").outerHeight()
// 			var p = b + m
// 			$("body").css("height", p)
// 		}, 500)
// 	})
// })

$(window).load(function(){
  $("#loader").hide();
   AOS.init({
      offset: 10, 
      duration: 2000,
      // once: true,
    });  
		setTimeout(function(){
			b = $("body").outerHeight()
		}, 500)
		$(document).on('click', '[data-accordian]', function(){
		  f = $(this).next(".toggle-box").find(".content-box").outerHeight()
			
		  $(this).parent().siblings().find('[data-accordian]').removeClass('active');
		  $(this).toggleClass('active');
		  $(this).parent().siblings().find('[data-accordian]').next().css("height", 0);
		  //$(this).next().css("height", 0);
		  //$(this).next().css("height", f);
		  $(this).parent(".acrd-row").siblings().removeClass("current")
		  $(this).parent(".acrd-row").toggleClass("current")
		  if($(this).parent(".acrd-row").hasClass("current")){
			$(this).next(".toggle-box").css("height", f);
			$("body").height(b + f - 20)
		  } else {
			$(this).next(".toggle-box").css("height", 0);
			$("body").height(b)
		  }
		  
		})
})



$(window).resize(function(){
  	var t = $(".banner-heading").outerHeight()
	$(".banner-content").css("top", -(t + 200))
});


