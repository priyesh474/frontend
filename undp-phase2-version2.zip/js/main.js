let loader = new IniLoaders({
    template: "linear",
    // timeOut: 4000, // milliseconde. 
    defaultOut: false,
    // removeAfterLoad:true,
    // animationOut:'slideDown', // slideDown, slideUp, slideLeft, slideRight - need activate defaultOut to "false"
    // testMode:true,
    
    params:{
        linear: {
             progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // style:{
                // tob_section_bg_color:'red',
                // bottom_section_bg_color:'green',
                // progress_color:'#232323',
            // }
        },
        pulsar: {
            // progressBar:true,
            // progressBar:{
            //     color:"red",
            // },
            // backgroundColor:"#f2f2f2",
            // color:"green"
            // color:{
                // first_circle:'yellow',
                // second_circle:'green',
            // }
        },
        cubs:{
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#f2f2f2",
            // image:'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg',
            // borderColor:{
                // boxLine:'yellow',
                // outLine:'green'
            // },
            // borderColor:"red",
        },
        resizeBox: {
            // progressBar:true,
            //  progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#232323",
            // speed:2000,
            // colors:{
                // one:'red',
                // two:'green',
                // three:'yellow',
                // four:'purple'
            // }
        },
        gearSet: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // backgroundColor:"#f2f2f2",
        },
        flash: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // colors:{
                // one:'red',
                // two:'green',
                // three:'yellow',
                // four:'purple',
                // fifth:'purple'
            // }
        },
        custom: {
            // progressBar:true,
            // progressBar:{
                // color:"red",
            // },
            // imagePath: 'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg',
            // backgroundColor:"#ffffff",
        }
    },
});

loader.event('start',function(promise) {
    promise.then(result => {
        console.log(result,'start');
        $("#map-img").attr("src", "img/green_map.png")
    })
});

loader.event('loaded',function(promise) {
    promise.then(result => {
        console.log(result,'loaded');
        //$("#map-img").attr("src", "img/green_map.svg")
    })
});

loader.event('percent_30',function(promise) {
    promise.then(result => {
        console.log(result,'percent');
    // $(".box_preload #progress").css({"visibility": "visible", "display": "block"});
    //$("#map-img").attr("src", "img/orange_map.svg")
    $("#map-img-orange, #map-img").addClass("active")
    })
});

loader.event('end',function(promise) {
    promise.then(result => {
        console.log(result,'end');
        $("#loader-wrapper").addClass("active")
        $(".box_preload.box_linear").hide()
        setTimeout(function(){
            $(".hero-banner .hero-map, .hero-banner .hero-heading, .hero-banner .download-btn, .viewport-bg").addClass("active")
        }, 700)
        
        
        // $(".hero-banner .download-btn").addClass("active")
        // //$(".box_preload").css("visibility", "hidden")
        // $("#map-img").addClass("zoom-img")
        // $("#map-img-orange").addClass("show-img")
        // setTimeout(function(){
        //     $("#map-img").css("display", "none")
        // }, 700)
        
    })
    
});



